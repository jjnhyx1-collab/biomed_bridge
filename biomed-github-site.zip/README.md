# BioMed Bridge

의생명공학 진로 포트폴리오 웹사이트입니다.  
GitHub Pages로 바로 배포할 수 있도록 `index.html`과 `style.css`로 구성했습니다.

## 파일 구성

- `index.html` : 사이트의 구조와 내용
- `style.css` : 사이트 디자인
- `README.md` : 프로젝트 설명

## GitHub Pages 배포 방법

1. GitHub에 로그인합니다.
2. 새 저장소를 만듭니다.
   - Repository name 예시: `biomed-bridge`
   - Public으로 설정합니다.
3. 이 폴더 안의 파일 3개를 업로드합니다.
   - `index.html`
   - `style.css`
   - `README.md`
4. 저장소 상단 메뉴에서 `Settings`로 들어갑니다.
5. 왼쪽 메뉴에서 `Pages`를 클릭합니다.
6. `Build and deployment`에서 다음처럼 설정합니다.
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
7. Save를 누릅니다.
8. 몇 분 뒤 `https://아이디.github.io/저장소이름/` 주소로 접속합니다.

## 수정할 부분

- `index.html`에서 이름, 탐구 주제, 실험 기록을 본인 내용으로 바꾸면 됩니다.
- `style.css`에서 색상, 간격, 글자 크기를 바꿀 수 있습니다.
